package com.kukuh.apphelm;

public class Helm {
    private String name;
    private String detail;
    private String rilis;
    private int photo;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) { this.detail = detail; }

    public String getRilis() { return rilis; }

    public void setRilis(String rilis) { this.rilis = rilis; }


    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }
}

