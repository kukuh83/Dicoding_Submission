package com.kukuh.apphelm;

import java.util.ArrayList;

class HelmData {
    private static String[] helmNames = {
            "Helm cakil",
            "KYT Vendetta 2  Espargaro",
            "NHK Predator",
            "INK CL MAX ",
            "MDS",
            "NJS",
            "ZEUS",
            "JPX",
            "Cakil HBC",
            "GM"
    };


    private static String[] helmDetails = {
            "CARGLOSS MXC MOTOCROSS - FZ ORANGE.",
            "KYT sendiri merupakan anak perusahaan dari PT Tarakusuma Indah yang juga memproduksi helm INK, MDS, BMC, dan HIU..",
            "helm NHK menjadi salah satu helm di kejuaraan MotoGP. Selain NHK termasuk helm yang sudah SNI, NHK juga termasuk Standar Transportasi Amerika atau yang sering disebut dengan DOT (Departement Of Transportation)..",
            "Semua helm INK juga telah lulus standar nasional Indonesia (SNI) dan ada beberapa tipe yang telah mendapatkan sertifikat Department of Transportation (DOT)..",
            "Karena bentuknya yang menyerupai helm cross, MDS Super Pro ini lebih dikenal dengan nama MDS supermoto. Namun bedanya dengan helm cross pada umumnya adalah helm MDS Super Pro ini memiliki visor..",
            "merknya NJS tipe Shadow 809R. Model dan desainnya menarik, sangat eye catching alias menarik mata untuk melihatnya dalam sekali lirik. .",
            "Menjadi helm full face entry level dari Zeus. Spesifikasi helm ini, Bahan shell helm dari ABS. Sertifikasi kemanan yang dimiliki adalah ECE, DOT, NBR, CNS, SNI.",
            "JPX adalah helm asli buatan indonesia. Dan fox1 ini adalah salah 1 series helm Cross nya JPX. Untuk standar keamanan, helm ini sudah menggunakan label SNI.",
            "Helm Branded Lokal dari Bandung yang diklaim sudah memproduksi helm Cakil Retro dengan standar SNI namanya HBC.",
            "Selain menggunakan label sertifikat SNI, helm GM Race Pro ini juga telah bersertifikat DOT. Standar sertifikat SNI dan DOT sudah cukup bagi helm yang dipakai bukan untuk race (circuit)."
    };

    private static int[] helmImages ={
            R.drawable.helm_cakil,
            R.drawable.kyt_vendeta,
            R.drawable.nhk,
            R.drawable.ink,
            R.drawable.mds,
            R.drawable.njs,
            R.drawable.zeus,
            R.drawable.jpx,
            R.drawable.hbc,
            R.drawable.gm
    };

    private static String[] Rilis = {
            "Harga Rp 500.000",
            "Harga Rp 800.000",
            "Harga Rp 1.000.000",
            "Harga Rp 950.000",
            "Harga Rp 500.000",
            "Harga Rp 800.000",
            "Harga Rp 1.000.000",
            "Harga Rp 2.000.000",
            "Harga Rp 950.000",
            "Harga Rp 950.000"
    };

    static ArrayList<Helm> getListData(){
        ArrayList<Helm> list = new ArrayList<>();
        for(int position = 0; position < helmNames.length; position++){
            Helm helm = new Helm();
            helm.setName(helmNames[position]);
            helm.setRilis(Rilis[position]);
            helm.setDetail(helmDetails[position]);
            helm.setPhoto(helmImages[position]);

            list.add(helm);
        }
        return list;
    }
}
