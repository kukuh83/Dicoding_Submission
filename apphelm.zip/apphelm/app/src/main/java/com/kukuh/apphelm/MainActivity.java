package com.kukuh.apphelm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvHelm;
    private ArrayList<Helm> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        rvHelm = findViewById(R.id.rv_helm);
        rvHelm .setHasFixedSize(true);

        list.addAll(HelmData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        rvHelm.setLayoutManager(new LinearLayoutManager(this));
        ListHelmAdapter listWisataAdapter = new ListHelmAdapter(list);
        rvHelm.setAdapter(listWisataAdapter);

        listWisataAdapter.setOnItemClickCallback(new ListHelmAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Helm data) {
                showSelectedData(data);
            }
        });
    }

    public void showSelectedData (Helm l){
        Intent detail = new Intent(MainActivity.this, DetailHelm.class);
        detail.putExtra(DetailHelm.EXTRA_NAMAHELM, l.getName());
        detail.putExtra(DetailHelm.EXTRA_RILIS, l.getRilis());
        detail.putExtra(DetailHelm.EXTRA_PENGERTIAN, l.getDetail());
        detail.putExtra(DetailHelm.EXTRA_IMG,l.getPhoto());
        startActivity(detail);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, About.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }


}